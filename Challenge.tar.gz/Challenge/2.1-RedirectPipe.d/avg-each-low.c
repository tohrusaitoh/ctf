#include <stdio.h>

// ((input))            ((output))
// saitoh  43  54 82    saitoh  59.67
// tomoko  89 100 32    tomoko  73.67
// mitsuki 79  68 93    mitsuki 80.00

int main() {
  char name[ 100 ] ;
  int  point[ 3 ] ;
  while( scanf( "%s%d%d%d" ,
		name , &point[0] , &point[1] , &point[2] ) == 4 ) {
    double sum = 0.0 ;
    for( int i = 0 ; i < 3 ; i++ )
      sum += point[i] ;
    printf( "%s %6.2f\n" , name , sum / 3.0 ) ;
  }
  return 0 ;
}
