#include <stdio.h>

// ((input))      ((output))
// saitoh  59.67  73.11
// tomoko  73.67
// mitsuki 80.00

int main() {
  char name[ 100 ] ;
  double point ;
  
  double sum = 0 ;
  int    count = 0 ;
  
  while( scanf( "%s%lf" , name , &point ) == 2 ) {
    sum += point ;
    count++ ;
  }
  printf( "%6.2f\n" , sum / (double)count ) ;
  return 0 ;
}
